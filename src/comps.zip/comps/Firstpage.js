// import React, { Component } from 'react'
// import Firstpageone from './FirstpageOne'
// import SecondpageOne from './SecondpageOne';

//  class Firstpage extends Component {
//     constructor(props) {
//         super(props);
        
    
//         this.state = {
//              matchNumber:1
//         }
        
//     }
//     changeNumber=(num)=>{
//         this.setState(
//             {matchNumber:num}
//         )
//     }

//     render() {
//         const num=this.state.matchNumber;
//         if(num===1)
//             return(
//                 <Firstpageone value={this.changeNumber}></Firstpageone>
//             )
//         if(num===2)
//             return(
//                 <SecondpageOne  num={num} value={this.changeNumber}></SecondpageOne>
//             )
//         if(num==3)
//                 return(
//                     <SecondpageOne num={num} value={this.changeNumber}></SecondpageOne>
//                 )
//         if(num==4)
//                 return(
//                     <SecondpageOne num={num} value={this.changeNumber}></SecondpageOne>
//                 )
//     }
// }

// export default Firstpage
